#!/bin/sh

make small_case.tst